package AntColonySim;

public enum AntType {

	QUEEN, FORAGER, SCOUT, SOLDIER, BALA;
	
}
